#!/bin/bash
echo "\$@ is $@"
echo "command line: $0 $*"
echo "hello world"
# Added
#~ echo "[$$] PAUSED... Hit return!"
#~ read DUMMY
#~ exit 0
